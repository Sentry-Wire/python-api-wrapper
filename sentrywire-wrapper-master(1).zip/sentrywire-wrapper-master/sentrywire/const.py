from sentrywire.__about__ import __title__, __version__

SERVER_PORT = 41395
TIMEOUT = 500

USER_AGENT = "{}/{}".format(__title__, __version__)
