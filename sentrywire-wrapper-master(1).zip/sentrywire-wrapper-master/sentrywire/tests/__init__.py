DOWNLOADS_FOLDER = "./downloads/"
TEST_DATA_FOLDER = "./test_data/"
